import mongoose from "mongoose";

export default mongoose.model(
  "247Guild",
  new mongoose.Schema({
    guildId: String
  })
);
