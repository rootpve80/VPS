import { nowPlayingEmbed, playerButtons } from "./nowPlaying.js";

export function registerPlayerEvents(manager) {
  manager.on("trackStart", (player, track) => {
    const channel = manager.client.channels.cache.get(player.textChannelId);
    if (!channel) return;

    channel.send({
      embeds: [nowPlayingEmbed(track)],
      components: [playerButtons()]
    });
  });

  manager.on("queueEnd", (player) => {
    const channel = manager.client.channels.cache.get(player.textChannelId);
    if (channel) channel.send("✅ Queue finished");
    player.destroy();
  });
}
