import { ActionRowBuilder, ButtonBuilder, ButtonStyle } from "discord.js";

export function nowPlayingEmbed(track) {
  return {
    title: "🎶 Now Playing",
    description: `**${track.info.title}**`,
    color: 0x2f3136
  };
}

export function playerButtons() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("pause").setLabel("⏸").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("resume").setLabel("▶️").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("skip").setLabel("⏭").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("shuffle").setLabel("🔀").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("stop").setLabel("⏹").setStyle(ButtonStyle.Danger)
  );
}
