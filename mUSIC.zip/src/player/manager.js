import { Manager } from "lavalink-client";

export const manager = new Manager({
  nodes: [
    {
      host: "lava-v4.ajieblogs.eu.org",   // agar same VPS
      port: 443,
      password: "https://dsc.gg/ajidevserver",
      secure: true
    }
  ],

  send: (guildId, payload) => {
    const guild = client.guilds.cache.get(guildId);
    if (guild) guild.shard.send(payload);
  }
});

