export default async (client, interaction) => {
  if (!interaction.isChatInputCommand()) return;

  const command = client.commands.get(interaction.commandName);
  if (!command) return;

  try {
    await command.execute(interaction, client);
  } catch (err) {
    console.error(err);
    if (interaction.replied || interaction.deferred) {
      interaction.followUp({ content: "❌ Error occurred", ephemeral: true });
    } else {
      interaction.reply({ content: "❌ Error occurred", ephemeral: true });
    }
  }
};
