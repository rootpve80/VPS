export default (client) => {
  console.log("✅ Event handler loaded");
};
