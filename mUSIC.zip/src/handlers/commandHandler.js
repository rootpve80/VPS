import fs from "fs";
import path from "path";

export default async (client) => {
  const commandsPath = path.join(process.cwd(), "src", "commands");
  if (!fs.existsSync(commandsPath)) return;

  const commandFolders = fs.readdirSync(commandsPath);

  for (const folder of commandFolders) {
    const folderPath = path.join(commandsPath, folder);
    const commandFiles = fs
      .readdirSync(folderPath)
      .filter(file => file.endsWith(".js"));

    for (const file of commandFiles) {
      const filePath = path.join(folderPath, file);
      const command = (await import(`file://${filePath}`)).default;

      if (!command?.name) continue;

      client.commands.set(command.name, command);
    }
  }

  console.log(`✅ Loaded ${client.commands.size} commands`);
};
