import 'dotenv/config';
import client from './client.js';
import './database/mongo.js';

client.login(process.env.TOKEN);
