export default {
  NOT_IN_VC: "❌ You are not connected to a voice channel.",
  NO_QUERY: "❌ Please provide a song name or URL.",
  NO_RESULTS: "❌ No results found for your search.",
  NOT_YOUR_INTERACTION: "❌ This menu is not for you.",
  ADDED_TRACK: (title) => `▶️ **${title}** has been added to the queue.`,
  SEARCH_TITLE: "🔍 Search Results",
  SEARCH_FOOTER: "Select a track using the buttons below"
};
