import os from "os";

export default {
  name: "botstats",
  execute(message) {
    const client = message.client;
    message.reply({
      embeds: [{
        title: "📊 Bot Stats",
        color: 0x2f3136,
        fields: [
          { name: "Servers", value: `${client.guilds.cache.size}`, inline: true },
          { name: "VC Connected", value: `${client.voice.adapters.size}`, inline: true },
          { name: "Ping", value: `${client.ws.ping}ms`, inline: true },
          { name: "RAM", value: `${(process.memoryUsage().rss / 1024 / 1024).toFixed(2)} MB`, inline: true },
          { name: "Uptime", value: `<t:${Math.floor(client.readyTimestamp/1000)}:R>`, inline: true }
        ]
      }]
    });
  }
};
