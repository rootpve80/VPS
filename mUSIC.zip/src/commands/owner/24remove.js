import Model from "../../database/models/247.js";

export default {
  name:"24remove",
  async execute(message,args){
    await Model.deleteOne({ guildId: args[0] });
    message.reply("❌ 24/7 removed");
  }
};

