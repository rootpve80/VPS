import Model from "../../database/models/247.js";

export default {
  name:"24list",
  async execute(message){
    const data = await Model.find();
    message.reply(
      data.length
        ? data.map(x=>x.guildId).join("\n")
        : "No 24/7 guilds"
    );
  }
};

