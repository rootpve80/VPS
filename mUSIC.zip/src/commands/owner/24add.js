export default {
  name: "24add",
  async execute(message,args){
    const id=args[0];
    if(!id) return;
    message.reply(`✅ 24/7 enabled for ${id}`);
  }
};
