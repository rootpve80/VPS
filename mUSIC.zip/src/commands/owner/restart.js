export default {
  name: "restart",
  execute(message) {
    message.reply("♻️ Restarting...").then(() => process.exit(0));
  }
};
