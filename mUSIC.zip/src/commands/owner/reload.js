export default {
  name: "reload",
  execute(message) {
    message.reply("🔄 Reload not needed (hot reload planned)");
  }
};
