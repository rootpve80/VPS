import { ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder } from "discord.js";
import config from "../../../config/config.js";

export default {
  name: "help",
  async execute(message) {
    const embed = {
      title: "🎵 Music Bot Help",
      description: "Use `/play` or `?play`\nChoose module below",
      color: config.embedColor
    };

    const menu = new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId("help_menu")
        .setPlaceholder("Select Module")
        .addOptions(
          { label:"Music", value:"music" },
          { label:"Filters", value:"filters" },
          { label:"Queue", value:"queue" }
        )
    );

    const buttons = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setLabel("Invite").setURL(config.invite).setStyle(ButtonStyle.Link),
      new ButtonBuilder().setLabel("Support").setURL(config.support).setStyle(ButtonStyle.Link)
    );

    await message.reply({ embeds:[embed], components:[menu,buttons] });
  }
};
