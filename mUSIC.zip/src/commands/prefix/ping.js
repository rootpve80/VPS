import { manager } from "../../player/manager.js";

export default {
  name: "ping",
  execute(message) {
    const node = manager.nodes.first();
    message.reply(
      `🏓 WS: ${message.client.ws.ping}ms\n` +
      `🎵 Lavalink: ${node?.stats?.ping || "N/A"}ms`
    );
  }
};

