import { manager } from "../../player/manager.js";
import messages from "../../utils/messages.js";
import { ActionRowBuilder, ButtonBuilder, ButtonStyle } from "discord.js";

export default {
  name: "play",
  async execute(message, args) {
    if (!message.member.voice.channel)
      return message.reply(messages.NOT_IN_VC);

    const query = args.join(" ");
    if (!query)
      return message.reply(messages.NO_QUERY);

    const res = await manager.search(query, message.author);
    if (!res.tracks.length)
      return message.reply(messages.NO_RESULTS);

    const row = new ActionRowBuilder().addComponents(
      res.tracks.slice(0, 5).map((_, i) =>
        new ButtonBuilder()
          .setCustomId(`play_${i}`)
          .setLabel(`${i + 1}`)
          .setStyle(ButtonStyle.Primary)
      )
    );

    const msg = await message.reply({
      embeds: [{
        title: messages.SEARCH_TITLE,
        description: res.tracks.slice(0, 5)
          .map((t, i) => `**${i + 1}.** ${t.info.title}`)
          .join("\n"),
        footer: { text: messages.SEARCH_FOOTER },
        color: 0x2f3136
      }],
      components: [row]
    });

    const collector = msg.createMessageComponentCollector({ time: 15000 });

    collector.on("collect", async i => {
      if (i.user.id !== message.author.id)
        return i.reply({ content: messages.NOT_YOUR_INTERACTION, ephemeral: true });

      const track = res.tracks[Number(i.customId.split("_")[1])];
      const player = manager.createPlayer({
        guildId: message.guild.id,
        voiceChannelId: message.member.voice.channel.id,
        textChannelId: message.channel.id,
        selfDeaf: true
      });

      if (!player.connected) await player.connect();
      player.queue.add(track);
      if (!player.playing) player.play();

      i.update({
        content: messages.ADDED_TRACK(track.info.title),
        embeds: [],
        components: []
      });
    });
  }
};

