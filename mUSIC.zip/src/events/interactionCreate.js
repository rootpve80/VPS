import { manager } from "../player/manager.js";

export default async (client, interaction) => {
  if (!interaction.isButton()) return;

  const player = manager.players.get(interaction.guildId);
  if (!player) return interaction.reply({ content: "❌ Player nahi hai", ephemeral: true });

  const memberVC = interaction.member.voice.channelId;
  if (memberVC !== player.voiceChannelId)
    return interaction.reply({ content: "❌ Same VC me ho", ephemeral: true });

  switch (interaction.customId) {
    case "pause":
      player.pause(true);
      break;
    case "resume":
      player.pause(false);
      break;
    case "skip":
      player.stop();
      break;
    case "stop":
      player.destroy();
      break;
    case "shuffle":
      player.queue.shuffle();
      break;
  }

  interaction.deferUpdate();
};
