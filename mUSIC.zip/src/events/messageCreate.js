import config from "../../config/config.js";
import isOwner from "../utils/isOwner.js";

export default async (client, message) => {
  if (message.author.bot) return;

  const prefix = config.prefix;
  const args = message.content.startsWith(prefix)
    ? message.content.slice(prefix.length).trim().split(/ +/)
    : message.content.split(/ +/);

  const cmdName = args.shift().toLowerCase();

  // OWNER NO PREFIX
  if (isOwner(message.author.id)) {
    const ownerCmd = client.ownerCommands.get(cmdName);
    if (ownerCmd) return ownerCmd.execute(message, args);
  }

  if (!message.content.startsWith(prefix)) return;

  const cmd = client.commands.get(cmdName);
  if (cmd) cmd.execute(message, args);
};
