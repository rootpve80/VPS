import { Client, GatewayIntentBits, Collection } from "discord.js";
import loadEvents from "./handlers/eventHandler.js";
import loadCommands from "./handlers/commandHandler.js";

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.MessageContent
  ]
});

client.commands = new Collection();
client.ownerCommands = new Collection();

await loadCommands(client);
loadEvents(client);

export default client;
