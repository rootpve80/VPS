export default {
  prefix: process.env.PREFIX || "?",
  owners: process.env.OWNER_IDS.split(","),
  embedColor: 0x2f3136,
  support: "https://discord.gg/yourserver",
  invite: "https://discord.com/oauth2/authorize?client_id=ID&permissions=8&scope=bot"
};
